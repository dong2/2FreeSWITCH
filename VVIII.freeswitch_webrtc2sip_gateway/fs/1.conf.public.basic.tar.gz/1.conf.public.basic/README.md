### 注意：
替换1.conf.public.basic整个目录到/usr/local/freeswitch/conf, 重启freeswitch即可  

1. Linphone on android 默认的设置里有个AVPF选项必须取消启动
2. Linphone on windows 设置里的AVPF选项默认是未启动的
3. Zoiper等其他软电话app默认配置一般都能正常拨通
4. sipml5 在firefox http://localhost下与各软电话能正常互拨通话
